# 地方政府融资平台分析

## Summary
This research covers key developments in 地方政府融资平台分析.

## Data Sources
- Wind Financial Terminal
- CEIC
- Company filings
- Industry associations