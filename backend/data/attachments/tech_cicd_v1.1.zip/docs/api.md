# API Reference

## GET /api/health
Returns service health status.

## POST /api/data
Submit data for processing.