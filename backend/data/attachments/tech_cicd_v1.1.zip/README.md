# CI/CD流水线配置

Version: v1.1

See docs/ folder for details.